<!DOCTYPE html>
<html>
  <head>
    <title>About</title>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <link rel="stylesheet" type="text/css" href="aboutdesign.css"/>
  </head>
  <body>
    <h1>WONG Oscar</h1>


  <form method="post" action="<?php echo strip_tags($_SERVER['REQUEST_URI']); ?>">
    <p>Real estate agent, Webmaster, Designer </p> <BR>



    <FONT size="2"> <p>I am a real estate agent living in California. I enjoy managing properties</p></FONT>

      <FONT size="2"> <p>and designing web applications, photography, surfing and music.</p></FONT>

    <FONT size="2"><p>Follow me on twitter or facebook. </p></FONT><BR>

 

  </form>

  </body>
</html>