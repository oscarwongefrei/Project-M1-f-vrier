
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>                                            <!--Cf https://cdnjs.com/libraries/jquery/3.2.1 -->
<script src="js/bootstrap.js"></script>	
</body>
</html>